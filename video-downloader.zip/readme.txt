Gotcha!!!

hacked by xNot_RespondinGx | ProblemCyberTeam

aku sudah lelah dengan semua ini,kuharap dunia hancur saja