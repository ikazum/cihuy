/**
 * Cloudflare Pages Function - Universal Video Proxy
 * Ekstrak video dari berbagai situs (termasuk yang sulit)
 */

export async function onRequestPost({ request }) {
    try {
        const body = await request.json();
        const targetUrl = body.url;

        if (!targetUrl) {
            return jsonResponse({ success: false, error: 'URL is required' }, 400);
        }

        // Validasi URL
        try {
            new URL(targetUrl);
        } catch {
            return jsonResponse({ success: false, error: 'Invalid URL format' }, 400);
        }

        // Fetch halaman
        const response = await fetch(targetUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Referer': new URL(targetUrl).origin,
            },
            redirect: 'follow'
        });

        const contentType = response.headers.get('content-type') || '';
        const isVideo = contentType.includes('video') || /\.(mp4|webm|ogg|mov|avi|mkv|flv|3gp|m3u8|ts)$/i.test(targetUrl);

        // === KASUS 1: URL langsung video ===
        if (isVideo) {
            return new Response(response.body, {
                headers: {
                    'Content-Type': contentType,
                    'Access-Control-Allow-Origin': '*',
                    'Cache-Control': 'public, max-age=3600',
                    'Content-Disposition': `inline; filename="video_${Date.now()}.mp4"`
                }
            });
        }

        // === KASUS 2: Halaman HTML ===
        if (contentType.includes('text/html')) {
            const html = await response.text();
            const videoUrls = [];
            const seen = new Set();

            // Fungsi bantu tambah URL
            const addUrl = (url, label = '') => {
                if (!url) return;
                try {
                    const full = new URL(url, targetUrl).href;
                    if (!seen.has(full)) {
                        seen.add(full);
                        videoUrls.push({ url: full, label: label || 'Video' });
                    }
                } catch (_) {}
            };

            // --- 1. Tag <video> dan <source> ---
            const videoTagRegex = /<(?:video|source)[^>]+src=["']([^"']+)["']/gi;
            let match;
            while ((match = videoTagRegex.exec(html)) !== null) {
                addUrl(match[1], 'Tag Video');
            }

            // --- 2. Atribut data-* umum ---
            const dataAttrRegex = /data-(?:src|video|url|file|source)["']?\s*=\s*["']([^"']+)["']/gi;
            while ((match = dataAttrRegex.exec(html)) !== null) {
                addUrl(match[1], 'Data Attribute');
            }

            // --- 3. Meta tag Open Graph ---
            const ogRegex = /<meta[^>]+property=["']og:video["'][^>]+content=["']([^"']+)["']/i;
            const ogMatch = ogRegex.exec(html);
            if (ogMatch) addUrl(ogMatch[1], 'Open Graph');

            // --- 4. Link <a> menuju video ---
            const aRegex = /<a[^>]+href=["']([^"']+\.(?:mp4|webm|mov|avi|mkv|m3u8|ts))["']/gi;
            while ((match = aRegex.exec(html)) !== null) {
                addUrl(match[1], 'Link');
            }

            // --- 5. JSON-LD (structured data) ---
            const jsonLdRegex = /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
            let jsonMatch;
            while ((jsonMatch = jsonLdRegex.exec(html)) !== null) {
                try {
                    const data = JSON.parse(jsonMatch[1]);
                    // Cari properti yang mengandung URL video
                    const extract = (obj, path = '') => {
                        if (!obj) return;
                        if (typeof obj === 'string') {
                            if (/\.(mp4|webm|mov|m3u8)/i.test(obj)) {
                                addUrl(obj, 'JSON-LD');
                            }
                            return;
                        }
                        if (Array.isArray(obj)) {
                            obj.forEach((item, i) => extract(item, `${path}[${i}]`));
                            return;
                        }
                        if (typeof obj === 'object') {
                            for (const key of ['url', 'contentUrl', 'videoUrl', 'embedUrl', 'file']) {
                                if (obj[key]) extract(obj[key], `${path}.${key}`);
                            }
                            // Rekursif untuk semua properti
                            for (const [k, v] of Object.entries(obj)) {
                                if (typeof v === 'object' && v !== null) {
                                    extract(v, `${path}.${k}`);
                                }
                            }
                        }
                    };
                    extract(data);
                } catch (_) {}
            }

            // --- 6. Skrip JavaScript yang mengandung konfigurasi player (regex tambahan) ---
            const scriptRegex = /<script[^>]*>([\s\S]*?)<\/script>/gi;
            while ((match = scriptRegex.exec(html)) !== null) {
                const scriptContent = match[1];
                // Cari pola seperti "file":"http...", "src":"http...", "video":"http..."
                const urlPatterns = /(?:file|src|video|url|source)["']?\s*[:=]\s*["']([^"']+\.(?:mp4|webm|m3u8|ts|mov|avi))["']/gi;
                let urlMatch;
                while ((urlMatch = urlPatterns.exec(scriptContent)) !== null) {
                    addUrl(urlMatch[1], 'JS Config');
                }
            }

            // --- 7. Style background-image ---
            const styleRegex = /style=["']([^"']*url\(["']?([^"')]+)["']?\)[^"']*)["']/gi;
            while ((match = styleRegex.exec(html)) !== null) {
                const urlMatch2 = /url\(["']?([^"')]+)["']?\)/.exec(match[1]);
                if (urlMatch2) {
                    addUrl(urlMatch2[1], 'Background');
                }
            }

            // Jika tidak ada video ditemukan
            if (videoUrls.length === 0) {
                return jsonResponse({
                    success: false,
                    error: 'Tidak ada video yang ditemukan di halaman ini. Pastikan URL benar dan halaman mengandung video.'
                }, 404);
            }

            return jsonResponse({
                success: true,
                videos: videoUrls,
                message: `Ditemukan ${videoUrls.length} video.`
            }, 200);
        }

        // === KASUS 3: Bukan HTML dan bukan video ===
        return jsonResponse({
            success: false,
            error: 'URL bukan halaman HTML atau file video yang didukung.'
        }, 415);

    } catch (error) {
        console.error('Error:', error);
        return jsonResponse({
            success: false,
            error: error.message || 'Internal Server Error'
        }, 500);
    }
}

// Helper untuk response JSON dengan CORS
function jsonResponse(data, status = 200) {
    return new Response(JSON.stringify(data), {
        status,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type',
        }
    });
}

// Tangani OPTIONS preflight
export async function onRequestOptions() {
    return new Response(null, {
        status: 204,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Max-Age': '86400',
        },
    });
}