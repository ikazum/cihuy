// functions/api/download.js
export async function onRequest(context) {
    // Hanya terima POST
    if (context.request.method !== 'POST') {
        return new Response(JSON.stringify({ success: false, message: 'Method not allowed' }), {
            status: 405,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    try {
        const { url } = await context.request.json();
        if (!url) throw new Error('URL tidak boleh kosong');

        let videoUrl = null;
        let platform = '';

        // Deteksi platform
        if (url.includes('instagram.com')) {
            platform = 'instagram';
            videoUrl = await extractInstagram(url);
        } else if (url.includes('facebook.com') || url.includes('fb.com')) {
            platform = 'facebook';
            videoUrl = await extractFacebook(url);
        } else if (url.includes('twitter.com') || url.includes('x.com')) {
            platform = 'twitter';
            videoUrl = await extractTwitter(url);
        } else {
            throw new Error('Platform tidak didukung. Gunakan Instagram, Facebook, atau Twitter/X.');
        }

        if (!videoUrl) {
            throw new Error(`Tidak dapat menemukan video di ${platform}. Pastikan URL publik dan benar.`);
        }

        return new Response(JSON.stringify({ success: true, videoUrl }), {
            headers: { 'Content-Type': 'application/json' }
        });

    } catch (err) {
        return new Response(JSON.stringify({ success: false, message: err.message }), {
            status: 400,
            headers: { 'Content-Type': 'application/json' }
        });
    }
}

// ---------- EKSTRAKTOR INSTAGRAM ----------
async function extractInstagram(url) {
    // Ambil halaman HTML
    const resp = await fetch(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
    });
    const html = await resp.text();

    // Cari JSON window._sharedData
    const regex = /window\._sharedData\s*=\s*({.*?});<\/script>/s;
    const match = html.match(regex);
    if (!match) throw new Error('Tidak ditemukan data Instagram (mungkin perlu login atau URL salah).');

    const data = JSON.parse(match[1]);
    const media = data?.entry_data?.PostPage?.[0]?.graphql?.shortcode_media;
    if (!media) throw new Error('Struktur halaman Instagram berubah.');

    // Prioritaskan video_url (untuk video), fallback ke display_url (gambar)
    if (media.video_url) return media.video_url;
    if (media.video_versions?.[0]?.url) return media.video_versions[0].url;

    throw new Error('Postingan ini bukan video atau tidak memiliki video yang dapat diunduh.');
}

// ---------- EKSTRAKTOR FACEBOOK ----------
async function extractFacebook(url) {
    const resp = await fetch(url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
    });
    const html = await resp.text();

    // Cari URL video HD atau SD di dalam JSON yang disematkan
    // Pola ini cukup stabil untuk video publik Facebook
    const hdMatch = html.match(/"browser_native_hd_url"\s*:\s*"([^"]+)"/);
    if (hdMatch) return hdMatch[1].replace(/\\/g, '');

    const sdMatch = html.match(/"browser_native_sd_url"\s*:\s*"([^"]+)"/);
    if (sdMatch) return sdMatch[1].replace(/\\/g, '');

    // Fallback: cari "playable_url"
    const playMatch = html.match(/"playable_url"\s*:\s*"([^"]+)"/);
    if (playMatch) return playMatch[1].replace(/\\/g, '');

    throw new Error('Tidak menemukan URL video Facebook. Pastikan video publik dan bukan Live.');
}

// ---------- EKSTRAKTOR TWITTER / X ----------
async function extractTwitter(url) {
    // Ganti domain dengan api.vxtwitter.com (proxy publik yang andal)
    let newUrl = url.replace('twitter.com', 'api.vxtwitter.com')
                    .replace('x.com', 'api.vxtwitter.com');
    // Hapus parameter tracking
    newUrl = newUrl.split('?')[0];

    const resp = await fetch(newUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0' }
    });
    if (!resp.ok) throw new Error('Gagal mengambil data dari Twitter proxy.');

    const json = await resp.json();
    const media = json?.media?.[0];
    if (!media) throw new Error('Tweet ini tidak memiliki video.');

    // Cari variant video/mp4 dengan bitrate tertinggi
    const variants = media?.video_info?.variants || [];
    const mp4Variants = variants.filter(v => v.content_type === 'video/mp4');
    if (mp4Variants.length === 0) throw new Error('Tidak ditemukan video MP4 di Tweet ini.');

    // Urutkan dari bitrate tertinggi
    mp4Variants.sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));
    return mp4Variants[0].url;
}